#include "lecteurvue.h"
#include "ui_lecteurvue.h"

LecteurVue::LecteurVue(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::LecteurVue)
{
    ui->setupUi(this);

    _numDiaporamaCourant = 0;   // =  le lecteur est vide

    // Connexion des boutons au méthode slot
    QObject::connect(ui->bSuivant , SIGNAL(clicked()),
                     this, SLOT(suivant()));
    QObject::connect(ui->bPrecedent, SIGNAL(clicked()),
                     this, SLOT(precedent()));
    QObject::connect(ui->bLancerDiapo, SIGNAL(clicked()),
                     this, SLOT(demarrerDiapo()));
    QObject::connect(ui->bArreterDiapo, SIGNAL(clicked()),
                     this, SLOT(arreterDiapo()));
    QObject::connect(ui->actionQuitter, SIGNAL(triggered()),
                     this, SLOT(fermerFenetre()));
    QObject::connect(ui->actionAProposDe, SIGNAL(triggered()),
                     this, SLOT(aProposDe()));
    QObject::connect(ui->actionEnleverLeDiaporama, SIGNAL(triggered()),
                     this, SLOT(enleverDiapo()));
    QObject::connect(ui->actionVitesseDeDefilement, SIGNAL(triggered()),
                     this, SLOT(vitesseDefilement()));
    QObject::connect(ui->actionCharger_le_diaporama, SIGNAL(triggered()),
                     this, SLOT(chargementDiaporama()));

    // Affichage d'un message dans la barre de statut
    ui->statusbar->showMessage("Mode MANUEL");
    ui->bArreterDiapo->setEnabled(false);

    // Création des images en dur
    _numDiaporamaCourant=1;
    Image* imageACharger;
    imageACharger = new Image(3, "Animal", "Pumba", "F:/cours-tp/SAE/S2/s201_DeveloppementApplication/V2_1/cartesDisney/Disney_31.gif");
    _diaporama.push_back(imageACharger);
    imageACharger = new Image(2, "Animal", "Mickey Mouse", "F:/cours-tp/SAE/S2/s201_DeveloppementApplication/V2_1/cartesDisney/Disney_19.gif");
    _diaporama.push_back(imageACharger);
    imageACharger = new Image(4, "Personne", "Blanche Neige", "F:/cours-tp/SAE/S2/s201_DeveloppementApplication/V2_1/cartesDisney/Disney_4.gif");
    _diaporama.push_back(imageACharger);
    imageACharger = new Image(1, "Animal", "Jiminy Cricket", "F:/cours-tp/SAE/S2/s201_DeveloppementApplication/V2_1/cartesDisney/Disney_25.gif");
    _diaporama.push_back(imageACharger);

    // Instanciation et connexion du timer
    timer = new QTimer(this);
    QObject::connect(timer,SIGNAL(timeout()),this, SLOT(finTimer()));
}

LecteurVue::~LecteurVue()
{
    delete ui;
}

void LecteurVue::suivant()
{
    qDebug() << "J'affiche l'image suivant" << Qt::endl;
    ui->statusbar->showMessage("Mode MANUEL");
    ui->bArreterDiapo->setEnabled(false);
    avancer();
    afficher();
    if (timer->isActive())
    {
        timer->stop();
    }
}

void LecteurVue::precedent()
{
    qDebug() << "J'affiche l'image précédente" << Qt::endl;
    ui->statusbar->showMessage("Mode MANUEL");
    ui->bArreterDiapo->setEnabled(false);
    reculer();
    afficher();
    if (timer->isActive())
    {
        timer->stop();
    }
}

void LecteurVue::demarrerDiapo()
{
    qDebug()<<"Je démarre le diaporama" << Qt::endl;
    ui->statusbar->showMessage("Mode AUTOMATIQUE");
    ui->bArreterDiapo->setEnabled(true);
    // Début du timer
    timer->start(2000);

}

void LecteurVue::arreterDiapo()
{
    qDebug()<<"J'arrete le diaporama" << Qt::endl;
    ui->statusbar->showMessage("Mode MANUEL");
    ui->bArreterDiapo->setEnabled(false);
    // Arret du timer
    timer->stop();
}

void LecteurVue::fermerFenetre()
{
    qDebug() <<"Je ferme la fenêtre" << Qt::endl;
    close();
}

void LecteurVue::aProposDe()
{
    qDebug()<<"J'affiche les informations de l'application" << Qt::endl;
    afficherInfoAppli();
}

void LecteurVue::vitesseDefilement()
{
    qDebug() << "Je modifie la vitesse de défilement du diaporama" << Qt::endl;
}

void LecteurVue::enleverDiapo()
{
    qDebug() << "J'enlève le diaporama" << Qt::endl;
    viderDiaporama();
}

void LecteurVue::afficherInfoAppli()
{
    QMessageBox::information(this,"À propos de l'application","Version : 3.0\nAuteur : Gauthier GOUMEAUX, Solène MARTIN, Anthony HERRMANN\nDate de création : 09/05/2023");
}

void LecteurVue::chargementDiaporama()
{
    qDebug() << "Je charge le diaporama" << Qt::endl;
    chargerDiaporama();
}

void LecteurVue::finTimer()
{
    avancer();
    afficher();
}

// ==============================
//      METHODE DE LECTEUR
// ==============================

void LecteurVue::avancer()
{
    if ((*this)._posImageCourante >= nbImages()-1)
    {
        (*this)._posImageCourante = 0;
    }
    else if (nbImages() > 0)
    {
        (*this)._posImageCourante = (*this)._posImageCourante + 1;
    }
}

void LecteurVue::reculer()
{
    if ((*this)._posImageCourante <= 0)
    {
        (*this)._posImageCourante = nbImages()-1;
    }
    else
    {
        (*this)._posImageCourante = (*this)._posImageCourante - 1;
    }
}

void LecteurVue::changerDiaporama(unsigned int pNumDiaporama)
{
    // s'il y a un diaporama courant, le vider, puis charger le nouveau Diaporama
    if (numDiaporamaCourant() > 0)
    {
        viderDiaporama();
    }
    _numDiaporamaCourant = pNumDiaporama;
    if (numDiaporamaCourant() > 0)
    {
        chargerDiaporama(); // charge le diaporama courant
    }

}

void LecteurVue::chargerDiaporama()
{
    /* Chargement des images associées au diaporama courant
       Dans une version ultérieure, ces données proviendront d'une base de données,
       et correspondront au diaporama choisi */
    _numDiaporamaCourant += 1;
    Image* imageACharger;
    imageACharger = new Image(3, "Animal", "Pumba", "F:/cours-tp/SAE/S2/s201_DeveloppementApplication/V2_1-Gauthier/cartesDisney/Disney_31.gif");
    _diaporama.push_back(imageACharger);
    imageACharger = new Image(2, "Animal", "Mickey Mouse", "F:/cours-tp/SAE/S2/s201_DeveloppementApplication/V2_1-Gauthier/cartesDisney/Disney_19.gif");
    _diaporama.push_back(imageACharger);
    imageACharger = new Image(4, "Personne", "Blanche Neige", "F:/cours-tp/SAE/S2/s201_DeveloppementApplication/V2_1-Gauthier/cartesDisney/Disney_4.gif");
    _diaporama.push_back(imageACharger);
    imageACharger = new Image(1, "Animal", "Jiminy Cricket", "F:/cours-tp/SAE/S2/s201_DeveloppementApplication/V2_1-Gauthier/cartesDisney/Disney_25.gif");
    _diaporama.push_back(imageACharger);


     // trier le contenu du diaporama par ordre croissant selon le rang de l'image dans le diaporama
    Image* img;
    for (unsigned int i = 0; i < nbImages()-1; i++) {
        for (unsigned int j = 0; j < nbImages()-i-1; j++) {
            if (_diaporama[j]->getRang() > _diaporama[j+1]->getRang()){
                img = _diaporama[j];
                _diaporama[j]=_diaporama[j+1];
                _diaporama[j+1]=img;
            }
        }
    }
     _posImageCourante = 0;

     cout << "Diaporama num. " << numDiaporamaCourant() << " selectionne. " << endl;
     cout << nbImages() << " images chargees dans le diaporama" << endl;
     afficher();

}

void LecteurVue::viderDiaporama()
{
    if (nbImages () > 0)
    {
        unsigned int taille = nbImages();
        for (unsigned int i = 0; i < taille ; i++)
        {
            _diaporama.pop_back(); /* Removes the last element in the vector,
                                      effectively reducing the container size by one.
                                      AND deletes the removed element */
        }
     _posImageCourante = 0;
    }
    cout << nbImages() << " images restantes dans le diaporama." << endl;
    ui->lPhoto->hide();

}

void LecteurVue::afficher()
{
     // affiche les information sur le lecteur :
     if (numDiaporamaCourant() != 0)
     {
         cout << "Numero diapo : " << numDiaporamaCourant() << endl;
         if (numDiaporamaCourant() > 0)
         {
             _diaporama[_posImageCourante]->Image::afficher();
             afficherTitrePhoto();
             afficherCategoriePhoto();
             afficherPhoto();
         }
     }
     else
     {
         cout << "Diaporama Vide" << endl;
     }
}

void LecteurVue::afficherTitrePhoto()
{
    ui->lTitrePhoto->setText(QString::fromStdString(imageCourante()->getTitre()));
}

void LecteurVue::afficherCategoriePhoto()
{
    ui->lCategorie->setText(QString::fromStdString(imageCourante()->getCategorie()));
}

void LecteurVue::afficherPhoto()
{
    ui->lPhoto->setPixmap(QPixmap(QString::fromStdString(imageCourante()->getChemin())));
}

unsigned int LecteurVue::nbImages()
{
    return _diaporama.size();
}

Image *LecteurVue::imageCourante()
{
    return _diaporama[_posImageCourante];
}

unsigned int LecteurVue::numDiaporamaCourant()
{
    return _numDiaporamaCourant;
}
